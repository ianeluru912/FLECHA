"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/mock-db"
import Navbar from "@/components/layout/navbar"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function MiPerfil() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [usuario, setUsuario] = useState<any>(null)
  const [pujas, setPujas] = useState<any[]>([])
  const [entradasGanadas, setEntradasGanadas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess) {
      router.push("/")
      return
    }
    setSession(sess)
    const user = db.getUser(sess.userId)
    setUsuario(user)
    const misPujas = db.getPujasByUser(sess.userId)
    setPujas(misPujas)

    const ganadas = db.getAllSubastas().filter((s) => s.estado === "terminada" && s.ganadorId === sess.userId)
    setEntradasGanadas(ganadas)

    setLoading(false)
  }, [router])

  if (loading) return null
  if (!session || !usuario) return null

  const pujasActivas = pujas.filter((p) => {
    const subasta = db.getSubasta(p.subastaId)
    return subasta?.estado === "activa"
  })

  const pujasTerminadas = pujas.filter((p) => {
    const subasta = db.getSubasta(p.subastaId)
    return subasta?.estado === "terminada"
  })

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Mi Perfil</h1>

        {entradasGanadas.length > 0 && (
          <Card className="p-6 mb-6 bg-gradient-to-r from-primary/10 to-accent/10 border-primary">
            <h2 className="text-2xl font-bold mb-4 text-primary">Entradas Ganadas</h2>
            <div className="space-y-3">
              {entradasGanadas.map((entrada) => (
                <div key={entrada.id} className="p-4 bg-card rounded-lg border border-primary/30">
                  <h3 className="font-bold mb-2">{entrada.titulo}</h3>
                  <p className="text-sm text-muted-foreground mb-3">
                    {entrada.ubicacion} • {entrada.categoria}
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-muted-foreground">
                      Precio final: <span className="text-accent font-bold">${entrada.precioActual}</span>
                    </span>
                    <Button size="sm" className="gradient-accent">
                      Ver Entrada
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 md:col-span-2">
            <h2 className="text-2xl font-bold mb-4">Información Personal</h2>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Nombre</p>
                <p className="text-lg font-semibold">{usuario.nombre}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Email</p>
                <p className="text-lg font-semibold">{usuario.email}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Rol</p>
                <p className="text-lg font-semibold capitalize">{usuario.rol}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">ID de Usuario</p>
                <p className="text-sm font-mono">{usuario.id}</p>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-bold mb-4">Billetera</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Saldo</p>
                <p className="text-3xl font-bold text-accent mb-2">
                  ${usuario.billetera.saldo.toLocaleString("es-AR")}
                </p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground mb-2">Dirección:</p>
                <p className="text-xs font-mono break-all">{usuario.billetera.direccion}</p>
              </div>
              <Link href="/billetera" className="text-primary text-sm hover:underline">
                Gestionar →
              </Link>
            </div>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Mis Pujas Activas</h3>
            {pujasActivas.length > 0 ? (
              <div className="space-y-3">
                {pujasActivas.map((puja) => {
                  const subasta = db.getSubasta(puja.subastaId)
                  const esGanador = subasta?.pujas[subasta.pujas.length - 1].usuarioId === session.userId
                  return (
                    <div key={puja.id} className="p-3 bg-muted/30 rounded-lg border border-border">
                      <p className="font-semibold text-sm mb-1">{subasta?.titulo}</p>
                      <p className="text-xs text-muted-foreground mb-2">Monto: ${puja.monto}</p>
                      <span
                        className={`text-xs px-2 py-1 rounded ${esGanador ? "bg-primary/20 text-primary" : "bg-muted/50 text-muted-foreground"}`}
                      >
                        {esGanador ? "Oferta ganadora" : "Activa"}
                      </span>
                    </div>
                  )
                })}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">No tienes pujas activas</p>
            )}
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Estadísticas</h3>
            <div className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Total de Pujas</p>
                <p className="text-3xl font-bold">{pujas.length}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Pujas Activas</p>
                <p className="text-2xl font-bold text-primary">{pujasActivas.length}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Subastas Terminadas</p>
                <p className="text-2xl font-bold">{pujasTerminadas.length}</p>
              </div>
            </div>
          </Card>
        </div>

        {pujasTerminadas.length > 0 && (
          <Card className="p-6 mt-6">
            <h3 className="text-xl font-bold mb-4">Historial Completo de Pujas</h3>
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {pujas.map((puja) => {
                const subasta = db.getSubasta(puja.subastaId)
                return (
                  <div
                    key={puja.id}
                    className="flex justify-between items-center text-sm p-3 bg-muted/20 rounded border border-border"
                  >
                    <div>
                      <p className="font-semibold">{subasta?.titulo}</p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(puja.timestamp).toLocaleDateString("es-AR")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold">${puja.monto}</p>
                      <p className="text-xs text-muted-foreground">{subasta?.estado}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </Card>
        )}
      </main>
    </div>
  )
}
