import { NextResponse } from "next/server"
import { db } from "@/lib/mock-db"

export async function GET(request: Request, { params }: { params: { id: string } }) {
  try {
    const subasta = db.getSubasta(params.id)

    if (!subasta) {
      return NextResponse.json({ error: "Subasta no encontrada" }, { status: 404 })
    }

    const now = new Date().getTime()
    const end = new Date(subasta.fechaFin).getTime()

    if (now >= end && subasta.estado === "activa") {
      const winnerId = db.determineWinner(subasta.id)

      db.updateSubasta(subasta.id, {
        estado: "terminada",
        ganadorId: winnerId || undefined,
      })

      const updatedSubasta = db.getSubasta(params.id)
      return NextResponse.json(updatedSubasta)
    }

    return NextResponse.json(subasta)
  } catch (error) {
    console.error("[v0] Error in GET /api/subastas/[id]:", error)
    return NextResponse.json({ error: "Error al obtener subasta" }, { status: 500 })
  }
}

export async function POST(request: Request, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { usuarioId, username, monto } = body

    const subasta = db.getSubasta(params.id)

    if (!subasta) {
      return NextResponse.json({ error: "Subasta no encontrada" }, { status: 404 })
    }

    const now = new Date().getTime()
    const end = new Date(subasta.fechaFin).getTime()

    if (now >= end || subasta.estado !== "activa") {
      return NextResponse.json({ error: "La subasta ha terminado" }, { status: 400 })
    }

    const pujaMinima = subasta.precioActual + subasta.pujaMinima

    if (monto < pujaMinima) {
      return NextResponse.json({ error: `La puja mínima es $${pujaMinima}` }, { status: 400 })
    }

    if (username) {
      if (!subasta.allowGuestBids) {
        return NextResponse.json({ error: "Esta subasta requiere cuenta de usuario" }, { status: 403 })
      }

      const guestBid = db.addGuestBid(params.id, username, monto)
      if (!guestBid) {
        return NextResponse.json({ error: "Error al registrar puja" }, { status: 500 })
      }

      return NextResponse.json({ success: true, bid: guestBid })
    } else if (usuarioId) {
      const puja = db.addPuja(params.id, usuarioId, monto)
      if (!puja) {
        return NextResponse.json({ error: "Error al realizar puja" }, { status: 500 })
      }
      return NextResponse.json({ success: true, bid: puja })
    }

    return NextResponse.json({ error: "Datos inválidos" }, { status: 400 })
  } catch (error) {
    console.error("[v0] Error in POST /api/subastas/[id]:", error)
    return NextResponse.json({ error: "Error al procesar puja" }, { status: 500 })
  }
}

export const dynamic = "force-dynamic"
