import { NextResponse } from "next/server"
import { db } from "@/lib/mock-db"

export async function GET() {
  try {
    const subastas = db.getAllSubastas()
    return NextResponse.json(subastas)
  } catch (error) {
    console.error("Error GET /api/subastas:", error)
    return NextResponse.json({ error: "Error al obtener subastas" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json()

    const {
      // datos para crear subasta
      titulo,
      descripcion,
      imagen,
      precioInicial,
      pujaMinima,
      categoria,
      ubicacion,
      fechaInicio,
      fechaFin,
      duenoId,
      allowGuestBids,

      // datos para pujar
      subastaId,
      usuarioId,
      username,
      monto,
    } = body

    // 🧩 Si viene monto + subastaId => lo tratamos como PUJA
    if (typeof monto === "number" && subastaId) {
      const subasta = db.getSubasta(subastaId)

      if (!subasta) {
        return NextResponse.json({ error: "Subasta no encontrada" }, { status: 404 })
      }

      const now = new Date().getTime()
      const end = new Date(subasta.fechaFin).getTime()

      if (now >= end || subasta.estado !== "activa") {
        return NextResponse.json({ error: "La subasta ha terminado" }, { status: 400 })
      }

      const pujaMinimaCalculada = subasta.precioActual + subasta.pujaMinima

      if (monto < pujaMinimaCalculada) {
        return NextResponse.json(
          { error: `La puja mínima es $${pujaMinimaCalculada}` },
          { status: 400 },
        )
      }

      // Invitado
      if (username) {
        if (!subasta.allowGuestBids) {
          return NextResponse.json(
            { error: "Esta subasta requiere cuenta de usuario" },
            { status: 403 },
          )
        }

        const guestBid = db.addGuestBid(subastaId, username, monto)
        if (!guestBid) {
          return NextResponse.json({ error: "Error al registrar puja" }, { status: 500 })
        }

        return NextResponse.json({ success: true, bid: guestBid })
      }

      // Usuario logueado
      if (usuarioId) {
        const puja = db.addPuja(subastaId, usuarioId, monto)
        if (!puja) {
          return NextResponse.json({ error: "Error al realizar puja" }, { status: 500 })
        }
        return NextResponse.json({ success: true, bid: puja })
      }

      return NextResponse.json({ error: "Datos inválidos" }, { status: 400 })
    }

    // 🧩 Si NO viene monto => lo tratamos como CREACIÓN de subasta
    if (!titulo || !descripcion || !precioInicial || !pujaMinima || !ubicacion || !categoria || !fechaFin || !duenoId) {
      return NextResponse.json({ error: "Datos incompletos" }, { status: 400 })
    }

    const nuevaSubasta = db.createSubasta({
      titulo,
      descripcion,
      imagen: imagen || "/placeholder.svg?key=default",
      precioInicial: Number(precioInicial),
      precioActual: Number(precioInicial),
      pujaMinima: Number(pujaMinima),
      categoria,
      ubicacion,
      fechaInicio: fechaInicio ? new Date(fechaInicio) : new Date(),
      fechaFin: new Date(fechaFin),
      estado: "activa",
      duenoId,
      allowGuestBids: !!allowGuestBids,
      ganadorId: undefined,
    })

    return NextResponse.json(nuevaSubasta, { status: 201 })
  } catch (error) {
    console.error("Error POST /api/subastas:", error)
    return NextResponse.json({ error: "Error al procesar solicitud" }, { status: 500 })
  }
}

export const dynamic = "force-dynamic"
