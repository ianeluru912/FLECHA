"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/mock-db"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import LoginForm from "@/components/auth/login-form"
import RegisterForm from "@/components/auth/register-form"
import Link from "next/link"

export default function Home() {
  const router = useRouter()
  const [isLogin, setIsLogin] = useState(true)
  const [session, setSession] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [showMarketplace, setShowMarketplace] = useState(false)
  const [subastas, setSubastas] = useState<any[]>([])
  const [filtro, setFiltro] = useState("")
  const [categoriaBuscada, setCategoriaBuscada] = useState("")

  useEffect(() => {
    const sess = getSession()
    if (sess) {
      setSession(sess)
      router.push("/subastas")
    } else {
      setLoading(false)
      // Load auctions for marketplace preview
      const allSubastas = db.getAllSubastas().filter((s) => s.estado === "activa")
      setSubastas(allSubastas)
    }
  }, [router])

  if (loading) return null

  const subastasFiltradas = subastas.filter(
    (s) =>
      (s.titulo.toLowerCase().includes(filtro.toLowerCase()) ||
        s.descripcion.toLowerCase().includes(filtro.toLowerCase())) &&
      (!categoriaBuscada || s.categoria === categoriaBuscada),
  )

  const categorias = [...new Set(subastas.map((s) => s.categoria))]

  if (showMarketplace) {
    return (
      <div className="min-h-screen bg-background">
        <nav className="bg-card border-b border-border sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
            <div className="text-2xl font-bold gradient-text">Flecha Tickets</div>
            <button
              onClick={() => setShowMarketplace(false)}
              className="px-4 py-2 text-primary hover:text-accent transition"
            >
              Volver
            </button>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 py-8">
          <h1 className="text-4xl font-bold mb-2">Entradas Disponibles</h1>
          <p className="text-muted-foreground mb-6">Explora y participa en subastas en vivo</p>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="md:col-span-2">
              <Input placeholder="Buscar entradas..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
            </div>
            <select
              value={categoriaBuscada}
              onChange={(e) => setCategoriaBuscada(e.target.value)}
              className="px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            >
              <option value="">Todas las categorías</option>
              {categorias.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
          </div>

          {subastasFiltradas.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {subastasFiltradas.map((subasta) => (
                <Link key={subasta.id} href={`/subastas/${subasta.id}`}>
                  <Card className="overflow-hidden hover:border-primary transition cursor-pointer h-full">
                    <img
                      src={subasta.imagen || "/placeholder.svg"}
                      alt={subasta.titulo}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <h3 className="font-bold text-lg mb-1 line-clamp-2">{subasta.titulo}</h3>
                      <p className="text-xs text-muted-foreground mb-3">
                        {subasta.ubicacion} • {subasta.categoria}
                      </p>

                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Precio actual:</span>
                          <span className="text-lg font-bold text-accent">${subasta.precioActual}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Puja mínima:</span>
                          <span className="text-sm">${subasta.pujaMinima}</span>
                        </div>
                      </div>

                      <Button className="w-full gradient-accent text-sm">Ver Detalles</Button>
                    </div>
                  </Card>
                </Link>
              ))}
            </div>
          ) : (
            <Card className="p-12 text-center">
              <p className="text-muted-foreground mb-4">No hay entradas disponibles en este momento</p>
              <Button onClick={() => setFiltro("")}>Limpiar filtros</Button>
            </Card>
          )}
        </main>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold gradient-text mb-2">Flecha Tickets</h1>
        </div>

        <Card className="p-6">
          {isLogin ? (
            <LoginForm onSuccess={() => router.push("/subastas")} />
          ) : (
            <RegisterForm onSuccess={() => router.push("/subastas")} />
          )}

          <div className="mt-6 text-center text-sm text-muted-foreground">
            {isLogin ? "¿No tienes cuenta? " : "¿Ya tienes cuenta? "}
            <button onClick={() => setIsLogin(!isLogin)} className="text-primary hover:underline font-semibold">
              {isLogin ? "Regístrate" : "Inicia sesión"}
            </button>
          </div>
        </Card>

        <div className="mt-8 p-4 bg-card rounded-lg border border-border">
          <p className="text-xs text-muted-foreground mb-2 font-semibold">Credenciales de demostración:</p>
          <div className="space-y-1 text-xs">
            <p className="text-muted-foreground">
              <span className="text-foreground">Admin:</span> admin@flechatickets.com / admin123
            </p>
            <p className="text-muted-foreground">
              <span className="text-foreground">Usuario:</span> usuario@flechatickets.com / user123
            </p>
            <p className="text-muted-foreground">
              <span className="text-foreground">Dueño:</span> dueno@flechatickets.com / dueno123
            </p>
          </div>
        </div>

        <Button onClick={() => setShowMarketplace(true)} variant="outline" className="w-full mt-4">
          Explorar Entradas Disponibles
        </Button>
      </div>
    </div>
  )
}
