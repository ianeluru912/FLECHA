"use client"

export const dynamic = "force-dynamic"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, useParams } from "next/navigation"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/mock-db"
import Navbar from "@/components/layout/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"


function BidConfirmationModal({ isOpen, onClose, onConfirm, monto, hasExistingBid, onBidTypeChange }: any) {
  const [bidType, setBidType] = useState<"add" | "replace">("add")

  const handleConfirm = () => {
    onBidTypeChange(bidType)
    onConfirm()
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-sm p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-2">Confirmar Puja</h2>
          <p className="text-muted-foreground">Estás a punto de hacer una puja de:</p>
        </div>

        <div className="bg-accent/10 border border-accent rounded-lg p-4">
          <p className="text-4xl font-bold text-accent">${monto.toLocaleString("es-AR")}</p>
        </div>

        {hasExistingBid && (
          <div className="space-y-3">
            <p className="font-semibold text-sm">¿Qué deseas hacer?</p>
            <div className="space-y-2">
              <label
                className="flex items-center p-3 border border-border rounded-lg cursor-pointer hover:bg-muted transition"
                htmlFor="add"
              >
                <input
                  id="add"
                  type="radio"
                  name="bid-type"
                  value="add"
                  checked={bidType === "add"}
                  onChange={() => setBidType("add")}
                  className="mr-3"
                />
                <div>
                  <p className="font-semibold text-sm">Agregar otra puja</p>
                  <p className="text-xs text-muted-foreground">Ambas pujas permanecerán activas</p>
                </div>
              </label>

              <label
                className="flex items-center p-3 border border-border rounded-lg cursor-pointer hover:bg-muted transition"
                htmlFor="replace"
              >
                <input
                  id="replace"
                  type="radio"
                  name="bid-type"
                  value="replace"
                  checked={bidType === "replace"}
                  onChange={() => setBidType("replace")}
                  className="mr-3"
                />
                <div>
                  <p className="font-semibold text-sm">Reemplazar puja anterior</p>
                  <p className="text-xs text-muted-foreground">Solo esta puja permanecerá activa</p>
                </div>
              </label>
            </div>
          </div>
        )}

        {!hasExistingBid && <p className="text-sm text-muted-foreground">Esta será tu primera puja en esta entrada.</p>}

        <div className="flex gap-3 pt-4">
          <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
            Cancelar
          </Button>
          <Button onClick={handleConfirm} className="flex-1 gradient-accent">
            Confirmar Puja
          </Button>
        </div>
      </Card>
    </div>
  )
}

function GuestUsernameModal({ isOpen, onClose, onConfirm, monto }: any) {
  const [username, setUsername] = useState("")

  const handleConfirm = () => {
    if (username.trim()) {
      onConfirm(username)
      setUsername("")
    }
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-sm p-6 space-y-6">
        <div>
          <h2 className="text-2xl font-bold mb-2">Ingresa tu Nombre de Usuario</h2>
          <p className="text-muted-foreground">Para participar en esta subasta</p>
        </div>

        <div className="bg-accent/10 border border-accent rounded-lg p-4">
          <p className="text-4xl font-bold text-accent">${monto.toLocaleString("es-AR")}</p>
        </div>

        <div>
          <Input
            placeholder="Tu nombre de usuario"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleConfirm()}
            autoFocus
          />
        </div>

        <div className="flex gap-3 pt-4">
          <Button onClick={onClose} variant="outline" className="flex-1 bg-transparent">
            Cancelar
          </Button>
          <Button onClick={handleConfirm} disabled={!username.trim()} className="flex-1 gradient-accent">
            Confirmar Puja
          </Button>
        </div>
      </Card>
    </div>
  )
}

export default function DetalleSubasta() {
  const router = useRouter()
  const params = useParams<{ id: string }>()
  const subastaId = params.id
  const [session, setSession] = useState<any>(null)
  const [subasta, setSubasta] = useState<any>(null)
  const [usuario, setUsuario] = useState<any>(null)
  const [monto, setMonto] = useState("")
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [showBidModal, setShowBidModal] = useState(false)
  const [showGuestModal, setShowGuestModal] = useState(false)
  const [bidType, setBidType] = useState<"add" | "replace">("add")
  const [timeRemaining, setTimeRemaining] = useState("")
  const [isGuest, setIsGuest] = useState(false)

    const fetchAuctionData = async () => {
    try {
      // 👇 SIEMPRE leemos de /api/subastas (la lista completa)
      const response = await fetch("/api/subastas", { cache: "no-store" })
      if (!response.ok) return

      const data = await response.json()
      const found = data.find((s: any) => s.id === subastaId)

      setSubasta(found || null)
    } catch (err) {
      console.error("[v0] Error fetching auction:", err)
    }
  }

  // Cargar sesión + subasta
  useEffect(() => {
    const sess = getSession()
    setSession(sess)

    if (sess) {
      const user = db.getUser(sess.userId)
      setUsuario(user)
    }

    // Carga inicial
    fetchAuctionData()

    // Refresco cada 2 segundos
    const interval = setInterval(fetchAuctionData, 2000)
    return () => clearInterval(interval)
  }, [subastaId])

  // Manejo de invitado / loading en función de la subasta
  useEffect(() => {
    if (!subasta) return

    // Si NO hay sesión y la subasta NO permite invitados → afuera
    if (!session && subasta && !subasta.allowGuestBids) {
      router.push("/")
      return
    }

    // Si no hay sesión pero sí se permiten invitados
    if (!session && subasta && subasta.allowGuestBids) {
      setIsGuest(true)
    }

    // Ya tenemos datos para mostrar
    setLoading(false)
  }, [session, subasta, router])


  useEffect(() => {
    if (!subasta) return

    const updateTime = () => {
      const now = new Date().getTime()
      const end = new Date(subasta.fechaFin).getTime()
      const diff = end - now

      if (diff <= 0) {
        setTimeRemaining("Terminada")
        return
      }

      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24)
      const minutes = Math.floor((diff / (1000 * 60)) % 60)
      const seconds = Math.floor((diff / 1000) % 60)

      setTimeRemaining(`${hours}h ${minutes}m ${seconds}s`)
    }

    updateTime()
    const timer = setInterval(updateTime, 1000)
    return () => clearInterval(timer)
  }, [subasta])

  const handlePujaClick = (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    const montoPuja = Number.parseFloat(monto)
    const montoMinimo = subasta.precioActual + subasta.pujaMinima

    if (isNaN(montoPuja) || montoPuja < montoMinimo) {
      setError(`La puja mínima es $${montoMinimo}`)
      return
    }

    if (subasta.estado !== "activa") {
      setError("La subasta ha terminado")
      return
    }

    if (!isGuest && usuario && usuario.billetera.saldo < montoPuja) {
      setError("No tienes saldo suficiente en tu billetera")
      return
    }

    if (isGuest && subasta.allowGuestBids) {
      setShowGuestModal(true)
    } else {
      setShowBidModal(true)
    }
  }

  const handleConfirmPuja = async () => {
    const montoPuja = Number.parseFloat(monto)

    if (bidType === "replace" && !isGuest && session) {
      const newSubasta = { ...subasta }
      newSubasta.pujas = newSubasta.pujas.filter((p: any) => p.usuarioId !== session.userId)
      db.updateSubasta(subasta.id, { pujas: newSubasta.pujas })
    }

    try {
      const response = await fetch(`/api/subastas`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subastaId: subasta.id,
        usuarioId: session?.userId,
        monto: montoPuja,
      }),
    })

      if (response.ok) {
        setMonto("")
        setShowBidModal(false)

        const mensaje = bidType === "replace" ? `Puja actualizada: $${montoPuja}` : `Puja agregada: $${montoPuja}`

        setSuccess(mensaje)
        setTimeout(() => setSuccess(""), 3000)

        fetchAuctionData()
      } else {
        const errorData = await response.json()
        setError(errorData.error || "Error al realizar la puja")
        setShowBidModal(false)
      }
    } catch (err) {
      console.error("[v0] Error submitting bid:", err)
      setError("Error de conexión")
      setShowBidModal(false)
    }
  }

  const handleConfirmGuestBid = async (username: string) => {
    const montoPuja = Number.parseFloat(monto)

    try {
      const response = await fetch(`/api/subastas`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        subastaId: subasta.id,
        username,
        monto: montoPuja,
      }),
    })


      if (response.ok) {
        setMonto("")
        setShowGuestModal(false)
        setSuccess(`Puja registrada: ${username}, $${montoPuja}`)
        setTimeout(() => setSuccess(""), 3000)

        fetchAuctionData()
      } else {
        const errorData = await response.json()
        setError(errorData.error || "Error al registrar la puja")
        setShowGuestModal(false)
      }
    } catch (err) {
      console.error("[v0] Error submitting guest bid:", err)
      setError("Error de conexión")
      setShowGuestModal(false)
    }
  }

  if (loading) return null
  if (!subasta) return null

  const pujaMinima = subasta.precioActual + subasta.pujaMinima
  const pujasDelUsuario = !isGuest && session ? subasta.pujas.filter((p: any) => p.usuarioId === session.userId) : []
  const tienePublicidadAnterior = pujasDelUsuario.length > 0
  const guestBidsCount = db.getGuestBids(subasta.id).length
  const isAuctionFinished = timeRemaining === "Terminada" || subasta.estado === "terminada"

  const getWinnerName = () => {
    if (!subasta.ganadorId) return null

    if (
      subasta.ganadorId.startsWith("user-") ||
      subasta.ganadorId.startsWith("admin-") ||
      subasta.ganadorId.startsWith("dueno-")
    ) {
      const winner = db.getUser(subasta.ganadorId)
      return winner?.username || "Usuario desconocido"
    }

    return subasta.ganadorId
  }

  return (
    <div className="min-h-screen bg-background">
      {session && <Navbar />}

      <main className="max-w-4xl mx-auto px-4 py-8">
        <Link href="/subastas" className="text-primary hover:underline text-sm mb-4 inline-block">
          ← Volver a entradas
        </Link>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Imagen */}
          <div>
            <img
              src={subasta.imagen || "/placeholder.svg"}
              alt={subasta.titulo}
              className="w-full rounded-lg border border-border mb-4"
            />
            <Card className="p-4">
              <p className="text-sm text-muted-foreground mb-1">Ubicación</p>
              <p className="font-semibold">{subasta.ubicacion}</p>
            </Card>
          </div>

          {/* Detalles */}
          <div>
            <div className="mb-6">
              <h1 className="text-3xl font-bold mb-2">{subasta.titulo}</h1>
              <p className="text-muted-foreground mb-4">{subasta.descripcion}</p>
              <div className="flex gap-2 mb-4">
                <span className="px-3 py-1 bg-primary/20 text-primary rounded-full text-sm">{subasta.categoria}</span>
              </div>
            </div>

            <Card className="p-6 mb-6">
              <div className="space-y-4">
                <div>
                  <p className="text-sm text-muted-foreground mb-1">Precio Inicial</p>
                  <p className="text-2xl font-bold">${subasta.precioInicial}</p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="text-sm text-muted-foreground mb-1">Precio Actual</p>
                  <p className="text-3xl font-bold text-accent">${subasta.precioActual}</p>
                </div>
                <div className="border-t border-border pt-4">
                  <p className="text-sm text-muted-foreground mb-1">Tiempo Restante</p>
                  <p className="text-xl font-bold text-primary">{timeRemaining}</p>
                </div>
                {isAuctionFinished && subasta.ganadorId && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground mb-1">Ganador</p>
                    <p className="text-2xl font-bold text-accent">🏆 {getWinnerName()}</p>
                  </div>
                )}
                {!isAuctionFinished && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground mb-1">Puja Mínima</p>
                    <p className="text-xl font-bold">${pujaMinima}</p>
                  </div>
                )}
                {pujasDelUsuario.length > 0 && (
                  <div className="border-t border-border pt-4">
                    <p className="text-sm text-muted-foreground mb-1">Tus Pujas</p>
                    <p className="text-lg font-bold text-primary">{pujasDelUsuario.length} puja(s)</p>
                  </div>
                )}
              </div>
            </Card>

            {(!isGuest || subasta.allowGuestBids) && (
              <Card className="p-6">
                <form onSubmit={handlePujaClick} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Tu Puja (ARS)</label>
                    <Input
                      type="number"
                      placeholder={`Mínimo $${pujaMinima}`}
                      value={monto}
                      onChange={(e) => setMonto(e.target.value)}
                      min={pujaMinima}
                      step="1"
                      disabled={isAuctionFinished}
                    />
                  </div>

                  {error && <p className="text-sm text-destructive">{error}</p>}
                  {success && <p className="text-sm text-primary">{success}</p>}

                  {!isGuest && usuario && !isAuctionFinished && (
                    <div className="text-xs text-muted-foreground">
                      Saldo disponible: ${usuario.billetera.saldo.toLocaleString("es-AR")}
                    </div>
                  )}

                  {isAuctionFinished ? (
                    <Button type="button" className="w-full bg-muted text-muted-foreground" disabled variant="outline">
                      No se puede pujar en una subasta terminada
                    </Button>
                  ) : (
                    <Button type="submit" className="w-full gradient-accent">
                      Realizar Puja
                    </Button>
                  )}
                </form>
              </Card>
            )}

            {(subasta.pujas.length > 0 || guestBidsCount > 0) && (
              <Card className="p-6 mt-6">
                <h3 className="font-bold mb-4">Últimas Pujas</h3>
                <div className="space-y-2 max-h-64 overflow-y-auto">
                  {[...subasta.pujas, ...db.getGuestBids(subasta.id)]
                    .sort((a: any, b: any) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                    .slice(0, 10)
                    .map((bid: any) => {
                      const isGuestBid = "username" in bid
                      const pujador = !isGuestBid ? db.getUser(bid.usuarioId) : null

                      return (
                        <div
                          key={bid.id}
                          className="flex justify-between items-center text-sm pb-2 border-b border-border"
                        >
                          <span className="text-muted-foreground">
                            {isGuestBid
                              ? bid.username
                              : bid.usuarioId === session?.userId
                                ? "Tú"
                                : pujador?.username || `Usuario ${bid.usuarioId.slice(0, 8)}`}
                          </span>
                          <span className="font-bold">${bid.monto}</span>
                        </div>
                      )
                    })}
                </div>
              </Card>
            )}
          </div>
        </div>
      </main>

      <BidConfirmationModal
        isOpen={showBidModal}
        onClose={() => setShowBidModal(false)}
        onConfirm={handleConfirmPuja}
        monto={Number.parseFloat(monto) || 0}
        hasExistingBid={tienePublicidadAnterior}
        onBidTypeChange={(type: "add" | "replace") => setBidType(type)}
      />

      <GuestUsernameModal
        isOpen={showGuestModal}
        onClose={() => setShowGuestModal(false)}
        onConfirm={handleConfirmGuestBid}
        monto={Number.parseFloat(monto) || 0}
      />
    </div>
  )
}
