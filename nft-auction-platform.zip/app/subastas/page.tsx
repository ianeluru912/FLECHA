"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import Navbar from "@/components/layout/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function Subastas() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [subastas, setSubastas] = useState<any[]>([])
  const [filtro, setFiltro] = useState("")
  const [categoriaBuscada, setCategoriaBuscada] = useState("")
  const [loading, setLoading] = useState(true)

  const fetchAuctions = async () => {
    try {
      const response = await fetch("/api/subastas")
      if (response.ok) {
        const data = await response.json()
        setSubastas(data.filter((s: any) => s.estado === "activa"))
      }
    } catch (err) {
      console.error("[v0] Error fetching auctions:", err)
    }
  }

  useEffect(() => {
    const sess = getSession()
    if (!sess) {
      router.push("/")
      return
    }
    setSession(sess)

    fetchAuctions()
    setLoading(false)

    const interval = setInterval(fetchAuctions, 2000)

    return () => clearInterval(interval)
  }, [router])

  const subastasFiltradas = subastas.filter(
    (s) =>
      (s.titulo.toLowerCase().includes(filtro.toLowerCase()) ||
        s.descripcion.toLowerCase().includes(filtro.toLowerCase())) &&
      (!categoriaBuscada || s.categoria === categoriaBuscada),
  )

  const categorias = [...new Set(subastas.map((s) => s.categoria))]

  if (loading) return null
  if (!session) return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Entradas Disponibles</h1>
        <p className="text-muted-foreground mb-6">Explora y participa en subastas en vivo</p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="md:col-span-2">
            <Input placeholder="Buscar entradas..." value={filtro} onChange={(e) => setFiltro(e.target.value)} />
          </div>
          <select
            value={categoriaBuscada}
            onChange={(e) => setCategoriaBuscada(e.target.value)}
            className="px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
          >
            <option value="">Todas las categorías</option>
            {categorias.map((cat) => (
              <option key={cat} value={cat}>
                {cat}
              </option>
            ))}
          </select>
        </div>

        {subastasFiltradas.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subastasFiltradas.map((subasta) => {
              const now = new Date().getTime()
              const end = new Date(subasta.fechaFin).getTime()
              const diff = end - now

              let timeDisplay = "Terminada"
              if (diff > 0) {
                const hours = Math.floor((diff / (1000 * 60 * 60)) % 24)
                const minutes = Math.floor((diff / (1000 * 60)) % 60)
                const seconds = Math.floor((diff / 1000) % 60)
                timeDisplay = `${hours}h ${minutes}m ${seconds}s`
              }

              return (
                <Link key={subasta.id} href={`/subastas/${subasta.id}`}>
                  <Card className="overflow-hidden hover:border-primary transition cursor-pointer h-full">
                    <img
                      src={subasta.imagen || "/placeholder.svg"}
                      alt={subasta.titulo}
                      className="w-full h-40 object-cover"
                    />
                    <div className="p-4">
                      <h3 className="font-bold text-lg mb-1 line-clamp-2">{subasta.titulo}</h3>
                      <p className="text-xs text-muted-foreground mb-3">
                        {subasta.ubicacion} • {subasta.categoria}
                      </p>

                      <div className="space-y-2 mb-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Precio actual:</span>
                          <span className="text-lg font-bold text-accent">${subasta.precioActual}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Puja mínima:</span>
                          <span className="text-sm">${subasta.pujaMinima}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground">Tiempo:</span>
                          <span className="text-sm font-semibold text-primary">{timeDisplay}</span>
                        </div>
                      </div>

                      <Button className="w-full gradient-accent text-sm">Ver Detalles</Button>
                    </div>
                  </Card>
                </Link>
              )
            })}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No hay subastas activas en este momento</p>
            <Button onClick={() => setFiltro("")}>Limpiar filtros</Button>
          </Card>
        )}
      </main>
    </div>
  )
}
