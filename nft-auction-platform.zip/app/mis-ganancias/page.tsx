'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Card } from '@/components/ui/card'

export default function MisGanancias() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [ganancias, setGanancias] = useState<any[]>([])
  const [totalGanado, setTotalGanado] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess) {
      router.push('/')
      return
    }
    setSession(sess)

    const todasLasSubastas = db.getAllSubastas()
    const misGanancias = todasLasSubastas.filter(s => s.ganadorId === sess.userId)
    setGanancias(misGanancias)
    
    let total = 0
    misGanancias.forEach(s => {
      total += s.precioActual
    })
    setTotalGanado(total)
    setLoading(false)
  }, [router])

  if (loading) return null
  if (!session) return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Mis Ganancias</h1>
        <p className="text-muted-foreground mb-8">Subastas que has ganado</p>

        <Card className="p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Total Ganado</p>
              <p className="text-4xl font-bold text-accent">${totalGanado.toLocaleString('es-AR')}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Subastas Ganadas</p>
              <p className="text-4xl font-bold">{ganancias.length}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground mb-1">Promedio por Subasta</p>
              <p className="text-4xl font-bold">
                ${ganancias.length > 0 ? Math.round(totalGanado / ganancias.length).toLocaleString('es-AR') : 0}
              </p>
            </div>
          </div>
        </Card>

        {ganancias.length > 0 ? (
          <Card className="p-6">
            <h2 className="text-2xl font-bold mb-4">Tus Ganancias</h2>
            <div className="space-y-3">
              {ganancias.map(subasta => (
                <div key={subasta.id} className="flex justify-between items-start p-4 bg-muted/20 rounded-lg border border-border">
                  <div className="flex-1">
                    <h3 className="font-semibold mb-1">{subasta.titulo}</h3>
                    <p className="text-sm text-muted-foreground mb-2">{subasta.ubicacion} • {subasta.categoria}</p>
                    <div className="flex items-center gap-4">
                      <span className="text-xs px-2 py-1 bg-primary/20 text-primary rounded">
                        Completada
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {new Date(subasta.fechaFin).toLocaleDateString('es-AR')}
                      </span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-accent">${subasta.precioActual}</p>
                    <p className="text-xs text-muted-foreground">Precio Final</p>
                  </div>
                </div>
              ))}
            </div>
          </Card>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">Aún no has ganado ninguna subasta</p>
            <p className="text-sm text-muted-foreground">Participa en subastas activas para ganar premios</p>
          </Card>
        )}
      </main>
    </div>
  )
}
