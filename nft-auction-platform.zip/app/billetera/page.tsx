'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'

export default function Billetera() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [usuario, setUsuario] = useState<any>(null)
  const [transacciones, setTransacciones] = useState<any[]>([])
  const [monto, setMonto] = useState('')
  const [metodo, setMetodo] = useState('mercadopago')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess) {
      router.push('/')
      return
    }
    setSession(sess)
    const user = db.getUser(sess.userId)
    setUsuario(user)
    const trans = db.getTransacciones(sess.userId)
    setTransacciones(trans)
    setLoading(false)
  }, [router])

  const handleDeposito = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    const montoDepositado = parseFloat(monto)
    if (isNaN(montoDepositado) || montoDepositado <= 0) {
      setError('Ingresa un monto válido')
      return
    }

    const transaccion = db.addTransaccion({
      usuarioId: session.userId,
      tipo: 'deposito',
      monto: montoDepositado,
      estado: 'exitoso',
      metodo: metodo as 'mercadopago' | 'crypto',
    })

    db.updateUserBalance(session.userId, usuario.billetera.saldo + montoDepositado)
    const userActualizado = db.getUser(session.userId)
    setUsuario(userActualizado)
    
    const trans = db.getTransacciones(session.userId)
    setTransacciones(trans)

    setMonto('')
    setSuccess(`¡Depósito exitoso! +$${montoDepositado}`)
    setTimeout(() => setSuccess(''), 3000)
  }

  if (loading) return null
  if (!session || !usuario) return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Mi Billetera</h1>
        <p className="text-muted-foreground mb-8">Gestiona tu saldo y realiza depósitos</p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6 md:col-span-2">
            <h2 className="text-2xl font-bold gradient-text mb-4">Saldo Disponible</h2>
            <p className="text-5xl font-bold mb-2">${usuario.billetera.saldo.toLocaleString('es-AR')}</p>
            <p className="text-sm text-muted-foreground">ARS (Pesos Argentinos)</p>
          </Card>

          <Card className="p-6">
            <h3 className="font-bold mb-2">Dirección Billetera</h3>
            <p className="text-xs font-mono break-all text-muted-foreground mb-4">
              {usuario.billetera.direccion}
            </p>
            <button
              onClick={() => navigator.clipboard.writeText(usuario.billetera.direccion)}
              className="text-xs text-primary hover:underline"
            >
              Copiar dirección
            </button>
          </Card>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Realizar Depósito</h3>
            <form onSubmit={handleDeposito} className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Método de Pago</label>
                <select
                  value={metodo}
                  onChange={(e) => setMetodo(e.target.value)}
                  className="w-full px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  <option value="mercadopago">MercadoPago</option>
                  <option value="crypto">Criptomoneda (BTC/ETH)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Monto a Depositar</label>
                <Input
                  type="number"
                  placeholder="500"
                  value={monto}
                  onChange={(e) => setMonto(e.target.value)}
                  min="1"
                  step="1"
                />
              </div>

              {error && <p className="text-sm text-destructive">{error}</p>}
              {success && <p className="text-sm text-primary">{success}</p>}

              <Button type="submit" className="w-full gradient-accent">
                Depositar
              </Button>

              <p className="text-xs text-muted-foreground text-center">
                Para demostración, el depósito es inmediato
              </p>
            </form>
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-bold mb-4">Últimas Transacciones</h3>
            {transacciones.length > 0 ? (
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {[...transacciones].reverse().map(trans => (
                  <div key={trans.id} className="flex justify-between items-center text-sm p-2 bg-muted/20 rounded">
                    <div>
                      <p className="font-semibold capitalize">{trans.tipo}</p>
                      <p className="text-xs text-muted-foreground">{trans.metodo}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-accent">+${trans.monto}</p>
                      <p className={`text-xs ${trans.estado === 'exitoso' ? 'text-primary' : 'text-muted-foreground'}`}>
                        {trans.estado}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground text-sm">Sin transacciones aún</p>
            )}
          </Card>
        </div>
      </main>
    </div>
  )
}
