"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/mock-db"
import Navbar from "@/components/layout/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function Dashboard() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [usuario, setUsuario] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess) {
      router.push("/")
      return
    }
    setSession(sess)
    const user = db.getUser(sess.userId)
    setUsuario(user)
    setLoading(false)
  }, [router])

  if (loading) return null

  if (!session) return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Bienvenido, {session.nombre}</h1>
          <p className="text-muted-foreground">Panel de control de Flecha Tickets</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Saldo de Billetera</div>
            <div className="text-3xl font-bold gradient-text mb-4">
              ${usuario?.billetera?.saldo?.toLocaleString("es-AR")}
            </div>
            <Link href="/billetera">
              <Button className="w-full bg-transparent" variant="outline">
                Gestionar Billetera
              </Button>
            </Link>
          </Card>

          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Mis Pujas Activas</div>
            <div className="text-3xl font-bold mb-4">0</div>
            <Link href="/mi-perfil">
              <Button className="w-full bg-transparent" variant="outline">
                Ver Historial
              </Button>
            </Link>
          </Card>

          <Card className="p-6">
            <div className="text-sm text-muted-foreground mb-1">Mis Ganancias</div>
            <div className="text-3xl font-bold text-accent mb-4">0</div>
            <Link href="/mis-ganancias">
              <Button className="w-full bg-transparent" variant="outline">
                Ver Detalles
              </Button>
            </Link>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card className="p-6 mb-6">
              <h2 className="text-2xl font-bold mb-4">Subastas Activas</h2>
              <div className="text-center text-muted-foreground py-8">
                <p className="mb-4">Navega a la sección de subastas para explorar ofertas disponibles</p>
                <Link href="/subastas">
                  <Button className="gradient-accent">Ver Todas las Subastas</Button>
                </Link>
              </div>
            </Card>
          </div>

          <Card className="p-6">
            <h3 className="text-lg font-bold mb-4">Información de Rol</h3>
            <div className="space-y-2 text-sm">
              <p>
                <span className="text-muted-foreground">Rol:</span> <span className="font-semibold">{session.rol}</span>
              </p>
              <p>
                <span className="text-muted-foreground">ID Usuario:</span>{" "}
                <span className="font-mono text-xs">{session.userId}</span>
              </p>
              <p>
                <span className="text-muted-foreground">Dirección:</span>{" "}
                <span className="font-mono text-xs">{usuario?.billetera?.direccion}</span>
              </p>
            </div>
          </Card>
        </div>
      </main>
    </div>
  )
}
