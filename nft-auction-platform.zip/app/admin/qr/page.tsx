"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { getSession } from "@/lib/auth"
import { db } from "@/lib/mock-db"
import Navbar from "@/components/layout/navbar"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import Link from "next/link"

export default function AdminQR() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [subastas, setSubastas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [zoomedQR, setZoomedQR] = useState<string | null>(null)

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== "admin") {
      router.push("/")
      return
    }
    setSession(sess)
    const allSubastas = db.getAllSubastas().filter((s) => s.estado === "activa")
    setSubastas(allSubastas)
    setLoading(false)
  }, [router])

  if (loading) return null
  if (!session || session.rol !== "admin") return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <Link href="/admin" className="text-primary hover:underline text-sm mb-4 inline-block">
            ← Volver al Panel
          </Link>
          <h1 className="text-4xl font-bold mb-2">Códigos QR para Subastas</h1>
          <p className="text-muted-foreground">Muestra estos QR para que los participantes se unan a las subastas</p>
        </div>

        {subastas.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {subastas.map((subasta) => (
              <Card key={subasta.id} className="p-6 flex flex-col items-center">
                <img
                  src="/qr-subasta-participar.png"
                  alt="QR Code"
                  className="w-48 h-48 rounded-lg border-2 border-primary mb-4 cursor-pointer hover:border-accent transition"
                  onClick={() => setZoomedQR(subasta.id)}
                />
                <p className="text-center font-bold mb-2 text-xl">{subasta.titulo}</p>
                <p className="text-center text-sm text-muted-foreground mb-4">
                  {subasta.ubicacion} • {subasta.categoria}
                </p>
                <div className="text-center mb-4 w-full">
                  <p className="text-xs text-muted-foreground mb-1">Precio Actual</p>
                  <p className="text-2xl font-bold text-accent">${subasta.precioActual}</p>
                </div>
                <div className="w-full p-3 bg-primary/10 rounded-lg border border-primary">
                  <p className="text-center text-lg font-bold text-primary">
                    ESCANEAR PARA PARTICIPAR
                    <br />
                    DE LA SUBASTA
                  </p>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No hay subastas activas en este momento</p>
            <Link href="/admin/subastas">
              <Button className="gradient-accent">Crear Subasta</Button>
            </Link>
          </Card>
        )}
      </main>

      {zoomedQR && (
        <div
          className="fixed inset-0 bg-black/80 flex items-center justify-center z-50 p-4"
          onClick={() => setZoomedQR(null)}
        >
          <div className="max-w-2xl w-full">
            <img
              src="/qr-subasta-participar.png"
              alt="QR Code Ampliado"
              className="w-full rounded-lg border-4 border-primary"
            />
            <p className="text-center text-white text-2xl font-bold mt-6">ESCANEAR PARA PARTICIPAR DE LA SUBASTA</p>
            <p className="text-center text-white/70 mt-2">Click para cerrar</p>
          </div>
        </div>
      )}
    </div>
  )
}
