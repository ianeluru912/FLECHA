'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export default function AdminDashboard() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [subastas, setSubastas] = useState<any[]>([])
  const [usuarios, setUsuarios] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== 'admin') {
      router.push('/')
      return
    }
    setSession(sess)
    setLoading(false)
  }, [router])

  useEffect(() => {
    if (session?.rol === 'admin') {
      const allSubastas = db.getAllSubastas()
      setSubastas(allSubastas)
    }
  }, [session])

  if (loading) return null
  if (!session || session.rol !== 'admin') return null

  const totalSubastas = subastas.length
  const subastaActivas = subastas.filter(s => s.estado === 'activa').length
  const subastaTerminadas = subastas.filter(s => s.estado === 'terminada').length
  const ingresoTotal = subastas.reduce((sum, s) => sum + s.precioActual, 0)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Panel de Administración</h1>
            <p className="text-muted-foreground">Gestión completa de subastas y plataforma</p>
          </div>
          <Link href="/admin/crear-subasta">
            <Button className="gradient-accent">+ Nueva Subasta</Button>
          </Link>
        </div>

        {/* Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-1">Total Subastas</p>
            <p className="text-3xl font-bold">{totalSubastas}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-1">Activas Ahora</p>
            <p className="text-3xl font-bold text-primary">{subastaActivas}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-1">Terminadas</p>
            <p className="text-3xl font-bold text-accent">{subastaTerminadas}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-1">Ingreso Total</p>
            <p className="text-3xl font-bold">${ingresoTotal.toLocaleString('es-AR')}</p>
          </Card>
        </div>

        {/* Navegación */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Link href="/admin/subastas">
            <Card className="p-6 hover:border-primary transition cursor-pointer">
              <h3 className="font-bold mb-2">Gestionar Subastas</h3>
              <p className="text-sm text-muted-foreground mb-4">Crear, editar y eliminar subastas</p>
              <Button variant="outline" className="w-full text-sm">Ver →</Button>
            </Card>
          </Link>
          
          <Link href="/admin/usuarios">
            <Card className="p-6 hover:border-primary transition cursor-pointer">
              <h3 className="font-bold mb-2">Gestionar Usuarios</h3>
              <p className="text-sm text-muted-foreground mb-4">Ver y administrar usuarios del sistema</p>
              <Button variant="outline" className="w-full text-sm">Ver →</Button>
            </Card>
          </Link>

          <Link href="/admin/reportes">
            <Card className="p-6 hover:border-primary transition cursor-pointer">
              <h3 className="font-bold mb-2">Reportes y Estadísticas</h3>
              <p className="text-sm text-muted-foreground mb-4">Análisis detallado de la plataforma</p>
              <Button variant="outline" className="w-full text-sm">Ver →</Button>
            </Card>
          </Link>

          <Link href="/admin/qr">
            <Card className="p-6 hover:border-primary transition cursor-pointer">
              <h3 className="font-bold mb-2">QR</h3>
              <p className="text-sm text-muted-foreground mb-4">Códigos QR para participación en subastas</p>
              <Button variant="outline" className="w-full text-sm">Ver →</Button>
            </Card>
          </Link>
        </div>

        {/* Últimas Subastas */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold mb-4">Últimas Subastas Creadas</h2>
          {subastas.length > 0 ? (
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-muted-foreground">
                    <th className="text-left py-2">Título</th>
                    <th className="text-left py-2">Estado</th>
                    <th className="text-right py-2">Precio Actual</th>
                    <th className="text-left py-2">Pujas</th>
                    <th className="text-left py-2">Acciones</th>
                  </tr>
                </thead>
                <tbody>
                  {subastas.slice(-5).reverse().map(subasta => (
                    <tr key={subasta.id} className="border-b border-border hover:bg-muted/20 transition">
                      <td className="py-3 font-semibold">{subasta.titulo}</td>
                      <td className="py-3">
                        <span className={`text-xs px-2 py-1 rounded-full ${
                          subasta.estado === 'activa' ? 'bg-primary/20 text-primary' :
                          subasta.estado === 'terminada' ? 'bg-accent/20 text-accent' :
                          'bg-destructive/20 text-destructive'
                        }`}>
                          {subasta.estado}
                        </span>
                      </td>
                      <td className="py-3 text-right font-bold">${subasta.precioActual}</td>
                      <td className="py-3">{subasta.pujas.length}</td>
                      <td className="py-3">
                        <Link href={`/admin/subastas/${subasta.id}`} className="text-primary hover:underline text-xs">
                          Editar
                        </Link>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="text-muted-foreground text-center py-8">No hay subastas creadas</p>
          )}
        </Card>
      </main>
    </div>
  )
}
