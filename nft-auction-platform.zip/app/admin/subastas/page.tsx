'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import Link from 'next/link'

export default function AdminSubastas() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [subastas, setSubastas] = useState<any[]>([])
  const [filtroEstado, setFiltroEstado] = useState('')
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== 'admin') {
      router.push('/')
      return
    }
    setSession(sess)
    const allSubastas = db.getAllSubastas()
    setSubastas(allSubastas)
    setLoading(false)
  }, [router])

  const subastasFiltradas = filtroEstado 
    ? subastas.filter(s => s.estado === filtroEstado)
    : subastas

  const handleEliminar = (id: string) => {
    if (confirm('¿Estás seguro que deseas eliminar esta subasta?')) {
      db.updateSubasta(id, { estado: 'cancelada' })
      setSubastas(db.getAllSubastas())
    }
  }

  const handleTerminar = (id: string) => {
    db.updateSubasta(id, { estado: 'terminada' })
    setSubastas(db.getAllSubastas())
  }

  if (loading) return null
  if (!session || session.rol !== 'admin') return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Gestión de Subastas</h1>
            <p className="text-muted-foreground">Administra todas las subastas de la plataforma</p>
          </div>
          <Link href="/admin/crear-subasta">
            <Button className="gradient-accent">+ Nueva Subasta</Button>
          </Link>
        </div>

        <div className="mb-6">
          <div className="flex gap-2">
            <button
              onClick={() => setFiltroEstado('')}
              className={`px-4 py-2 rounded-lg text-sm transition ${
                filtroEstado === '' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              Todas ({subastas.length})
            </button>
            <button
              onClick={() => setFiltroEstado('activa')}
              className={`px-4 py-2 rounded-lg text-sm transition ${
                filtroEstado === 'activa' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              Activas ({subastas.filter(s => s.estado === 'activa').length})
            </button>
            <button
              onClick={() => setFiltroEstado('terminada')}
              className={`px-4 py-2 rounded-lg text-sm transition ${
                filtroEstado === 'terminada' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              Terminadas ({subastas.filter(s => s.estado === 'terminada').length})
            </button>
            <button
              onClick={() => setFiltroEstado('cancelada')}
              className={`px-4 py-2 rounded-lg text-sm transition ${
                filtroEstado === 'cancelada' 
                  ? 'bg-primary text-primary-foreground' 
                  : 'bg-muted text-muted-foreground hover:bg-muted/80'
              }`}
            >
              Canceladas ({subastas.filter(s => s.estado === 'cancelada').length})
            </button>
          </div>
        </div>

        {subastasFiltradas.length > 0 ? (
          <div className="space-y-4">
            {subastasFiltradas.map(subasta => (
              <Card key={subasta.id} className="p-6">
                <div className="flex gap-6">
                  <img
                    src={subasta.imagen || '/placeholder.svg'}
                    alt={subasta.titulo}
                    className="w-32 h-32 object-cover rounded-lg"
                  />
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <div>
                        <h3 className="text-xl font-bold">{subasta.titulo}</h3>
                        <p className="text-sm text-muted-foreground">{subasta.ubicacion} • {subasta.categoria}</p>
                      </div>
                      <span className={`text-xs px-3 py-1 rounded-full font-semibold ${
                        subasta.estado === 'activa' ? 'bg-primary/20 text-primary' :
                        subasta.estado === 'terminada' ? 'bg-accent/20 text-accent' :
                        'bg-destructive/20 text-destructive'
                      }`}>
                        {subasta.estado}
                      </span>
                    </div>

                    <div className="grid grid-cols-4 gap-4 my-4">
                      <div>
                        <p className="text-xs text-muted-foreground">Precio Inicial</p>
                        <p className="font-bold">${subasta.precioInicial}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Precio Actual</p>
                        <p className="font-bold text-accent">${subasta.precioActual}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Pujas</p>
                        <p className="font-bold">{subasta.pujas.length}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Ganador</p>
                        <p className="font-bold">{subasta.ganadorId ? 'Asignado' : 'Pendiente'}</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Link href={`/admin/subastas/${subasta.id}`}>
                        <Button variant="outline" size="sm">Editar</Button>
                      </Link>
                      {subasta.estado === 'activa' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleTerminar(subasta.id)}
                          className="text-accent"
                        >
                          Terminar
                        </Button>
                      )}
                      {subasta.estado !== 'cancelada' && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleEliminar(subasta.id)}
                          className="text-destructive"
                        >
                          Cancelar
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground mb-4">No hay subastas para mostrar</p>
            <Link href="/admin/crear-subasta">
              <Button className="gradient-accent">Crear Primera Subasta</Button>
            </Link>
          </Card>
        )}
      </main>
    </div>
  )
}
