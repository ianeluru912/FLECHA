'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Card } from '@/components/ui/card'

export default function AdminReportes() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [subastas, setSubastas] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== 'admin') {
      router.push('/')
      return
    }
    setSession(sess)
    const allSubastas = db.getAllSubastas()
    setSubastas(allSubastas)
    setLoading(false)
  }, [router])

  if (loading) return null
  if (!session || session.rol !== 'admin') return null

  const totalIngreso = subastas.reduce((sum, s) => sum + s.precioActual, 0)
  const totalPujas = subastas.reduce((sum, s) => sum + s.pujas.length, 0)
  const pujasPromedio = subastas.length > 0 ? Math.round(totalPujas / subastas.length) : 0
  const precioPromedio = subastas.length > 0 ? Math.round(totalIngreso / subastas.length) : 0

  const topSubastas = [...subastas].sort((a, b) => b.precioActual - a.precioActual).slice(0, 5)

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Reportes y Estadísticas</h1>
        <p className="text-muted-foreground mb-8">Análisis detallado de la plataforma</p>

        {/* KPIs Principales */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Ingreso Total</p>
            <p className="text-4xl font-bold text-accent">${totalIngreso.toLocaleString('es-AR')}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Total Pujas</p>
            <p className="text-4xl font-bold">{totalPujas}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Pujas Promedio</p>
            <p className="text-4xl font-bold">{pujasPromedio}</p>
          </Card>
          <Card className="p-6">
            <p className="text-sm text-muted-foreground mb-2">Precio Promedio</p>
            <p className="text-4xl font-bold">${precioPromedio.toLocaleString('es-AR')}</p>
          </Card>
        </div>

        {/* Estados de Subastas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="p-6">
            <h3 className="font-bold mb-4">Por Estado</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Activas</span>
                <span className="font-bold text-primary">{subastas.filter(s => s.estado === 'activa').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Terminadas</span>
                <span className="font-bold text-accent">{subastas.filter(s => s.estado === 'terminada').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Canceladas</span>
                <span className="font-bold text-destructive">{subastas.filter(s => s.estado === 'cancelada').length}</span>
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-bold mb-4">Por Categoría</h3>
            <div className="space-y-2">
              {[...new Set(subastas.map(s => s.categoria))].map(cat => (
                <div key={cat} className="flex justify-between">
                  <span className="text-sm">{cat}</span>
                  <span className="font-bold">{subastas.filter(s => s.categoria === cat).length}</span>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-bold mb-4">Actividad</h3>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm">Total Subastas</span>
                <span className="font-bold">{subastas.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Con Pujas</span>
                <span className="font-bold">{subastas.filter(s => s.pujas.length > 0).length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Sin Pujas</span>
                <span className="font-bold">{subastas.filter(s => s.pujas.length === 0).length}</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Top Subastas */}
        <Card className="p-6">
          <h2 className="text-2xl font-bold mb-4">Top 5 Subastas por Ingreso</h2>
          <div className="space-y-3">
            {topSubastas.map((subasta, index) => (
              <div key={subasta.id} className="flex items-center justify-between p-3 bg-muted/20 rounded-lg border border-border">
                <div className="flex items-center gap-4">
                  <div className="w-8 h-8 rounded-full bg-primary/20 text-primary flex items-center justify-center font-bold text-sm">
                    {index + 1}
                  </div>
                  <div>
                    <p className="font-semibold">{subasta.titulo}</p>
                    <p className="text-xs text-muted-foreground">{subasta.pujas.length} pujas • {subasta.estado}</p>
                  </div>
                </div>
                <p className="text-lg font-bold text-accent">${subasta.precioActual.toLocaleString('es-AR')}</p>
              </div>
            ))}
          </div>
        </Card>
      </main>
    </div>
  )
}
