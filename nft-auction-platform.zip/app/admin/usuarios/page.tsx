'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import { db } from '@/lib/mock-db'
import Navbar from '@/components/layout/navbar'
import { Card } from '@/components/ui/card'

export default function AdminUsuarios() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [usuarios, setUsuarios] = useState<any[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== 'admin') {
      router.push('/')
      return
    }
    setSession(sess)
    
    // Obtener usuarios (simulado)
    const allUsers = JSON.parse(localStorage.getItem('subasta_users') || '[]')
    setUsuarios(allUsers)
    setLoading(false)
  }, [router])

  if (loading) return null
  if (!session || session.rol !== 'admin') return null

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-7xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Gestión de Usuarios</h1>
        <p className="text-muted-foreground mb-8">Administra todos los usuarios de la plataforma</p>

        {usuarios.length > 0 ? (
          <Card className="p-6">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-border">
                  <tr className="text-muted-foreground">
                    <th className="text-left py-3">Nombre</th>
                    <th className="text-left py-3">Email</th>
                    <th className="text-left py-3">Rol</th>
                    <th className="text-right py-3">Saldo Billetera</th>
                    <th className="text-left py-3">Dirección</th>
                  </tr>
                </thead>
                <tbody>
                  {usuarios.map(usuario => (
                    <tr key={usuario.id} className="border-b border-border hover:bg-muted/20 transition">
                      <td className="py-3 font-semibold">{usuario.nombre}</td>
                      <td className="py-3 text-muted-foreground">{usuario.email}</td>
                      <td className="py-3">
                        <span className={`text-xs px-2 py-1 rounded font-semibold ${
                          usuario.rol === 'admin' ? 'bg-primary/20 text-primary' :
                          usuario.rol === 'dueño' ? 'bg-accent/20 text-accent' :
                          'bg-muted/50 text-muted-foreground'
                        }`}>
                          {usuario.rol}
                        </span>
                      </td>
                      <td className="py-3 text-right font-bold">
                        ${usuario.billetera.saldo.toLocaleString('es-AR')}
                      </td>
                      <td className="py-3 text-xs font-mono text-muted-foreground">
                        {usuario.billetera.direccion.slice(0, 16)}...
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <div className="mt-6 pt-6 border-t border-border">
              <div className="grid grid-cols-4 gap-4">
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Total Usuarios</p>
                  <p className="text-2xl font-bold">{usuarios.length}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Administradores</p>
                  <p className="text-2xl font-bold">{usuarios.filter(u => u.rol === 'admin').length}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Dueños</p>
                  <p className="text-2xl font-bold">{usuarios.filter(u => u.rol === 'dueño').length}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-1">Usuarios Regulares</p>
                  <p className="text-2xl font-bold">{usuarios.filter(u => u.rol === 'usuario').length}</p>
                </div>
              </div>
            </div>
          </Card>
        ) : (
          <Card className="p-12 text-center">
            <p className="text-muted-foreground">No hay usuarios registrados</p>
          </Card>
        )}
      </main>
    </div>
  )
}
