'use client'

import { useEffect, useState } from 'react'
import { useRouter } from 'next/navigation'
import { getSession } from '@/lib/auth'
import Navbar from '@/components/layout/navbar'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { Input } from '@/components/ui/input'


export default function CrearSubasta() {
  const router = useRouter()
  const [session, setSession] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [allowGuestBids, setAllowGuestBids] = useState(true)
  const [titulo, setTitulo] = useState('')
  const [descripcion, setDescripcion] = useState('')
  const [precioInicial, setPrecioInicial] = useState('')
  const [pujaMinima, setPujaMinima] = useState('')
  const [categoria, setCategoria] = useState('Entretenimiento')
  const [ubicacion, setUbicacion] = useState('')
  const [imagen, setImagen] = useState('')
  const [error, setError] = useState('')
  const [success, setSuccess] = useState('')

  useEffect(() => {
    const sess = getSession()
    if (!sess || sess.rol !== 'admin') {
      router.push('/')
      return
    }
    setSession(sess)
    setLoading(false)
  }, [router])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setSuccess('')

    if (!titulo || !descripcion || !precioInicial || !pujaMinima || !ubicacion) {
      setError('Por favor completa todos los campos')
      return
    }

    const duenoId = session?.userId || 'admin-1'
    const precioInicialNum = parseFloat(precioInicial)
    const pujaMinimaNum = parseFloat(pujaMinima)

    try {
      const res = await fetch('/api/subastas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          titulo,
          descripcion,
          imagen,
          precioInicial: precioInicialNum,
          pujaMinima: pujaMinimaNum,
          categoria,
          ubicacion,
          // misma lógica: subasta dura 7 días
          fechaFin: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
          duenoId,
          allowGuestBids,
        }),
      })

      if (!res.ok) {
        const data = await res.json().catch(() => ({}))
        setError(data.error || 'Error al crear la subasta')
        return
      }

      setSuccess('Subasta creada exitosamente')
      setTimeout(() => {
        router.push('/admin/subastas')
      }, 1500)
    } catch (err) {
      console.error(err)
      setError('Error de conexión')
    }
  }


  if (loading) return null
  if (!session || session.rol !== 'admin') return null

  const categorias = ['Entretenimiento', 'Deportes', 'Arte', 'Tecnología', 'Otros']

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      
      <main className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-2">Crear Nueva Subasta</h1>
        <p className="text-muted-foreground mb-8">Ingresa los detalles de la nueva subasta</p>

        <Card className="p-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium mb-2">Título de la Subasta</label>
              <Input
                type="text"
                value={titulo}
                onChange={(e) => setTitulo(e.target.value)}
                placeholder="Ej: Entrada VIP - Festival de Música"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Descripción</label>
              <textarea
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                placeholder="Describe la subasta con detalle..."
                className="w-full px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary min-h-24"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Precio Inicial ($)</label>
                <Input
                  type="number"
                  value={precioInicial}
                  onChange={(e) => setPrecioInicial(e.target.value)}
                  placeholder="500"
                  min="1"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Puja Mínima ($)</label>
                <Input
                  type="number"
                  value={pujaMinima}
                  onChange={(e) => setPujaMinima(e.target.value)}
                  placeholder="100"
                  min="1"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Categoría</label>
                <select
                  value={categoria}
                  onChange={(e) => setCategoria(e.target.value)}
                  className="w-full px-3 py-2 bg-input border border-border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-primary"
                >
                  {categorias.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Ubicación</label>
                <Input
                  type="text"
                  value={ubicacion}
                  onChange={(e) => setUbicacion(e.target.value)}
                  placeholder="Buenos Aires"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">URL de Imagen</label>
              <Input
                type="text"
                value={imagen}
                onChange={(e) => setImagen(e.target.value)}
                placeholder="/placeholder.svg?key=myimage"
              />
              <p className="text-xs text-muted-foreground mt-1">Opcional. Usa URLs válidas de imágenes</p>
            </div>

            <div className="flex items-center gap-2">
              <input
                id="allow-guest"
                type="checkbox"
                checked={allowGuestBids}
                onChange={(e) => setAllowGuestBids(e.target.checked)}
                className="w-4 h-4"
              />
              <label htmlFor="allow-guest" className="text-sm">
                Permitir pujas de invitados (solo nombre + monto, sin cuenta)
              </label>
            </div>

            {error && <p className="text-sm text-destructive">{error}</p>}
            {success && <p className="text-sm text-primary">{success}</p>}

            <div className="flex gap-4 pt-4">
              <Button type="submit" className="flex-1 gradient-accent">
                Crear Subasta
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={() => router.back()}
                className="flex-1"
              >
                Cancelar
              </Button>
            </div>
          </form>
        </Card>
      </main>
    </div>
  )
}
