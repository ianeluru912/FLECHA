'use client'

import { useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { getSession, logout } from '@/lib/auth'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'

export default function Navbar() {
  const router = useRouter()
  const [session, setSession] = useState<any>(getSession())
  const [showMenu, setShowMenu] = useState(false)

  const handleLogout = () => {
    logout()
    router.push('/')
  }

  return (
    <nav className="bg-card border-b border-border sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex justify-between items-center">
        <Link href="/dashboard" className="text-2xl font-bold gradient-text">
          Flecha Tickets
        </Link>

        {session && (
          <div className="flex items-center gap-4">
            <Link href="/dashboard" className="text-sm hover:text-primary transition">
              Inicio
            </Link>
            <Link href="/subastas" className="text-sm hover:text-primary transition">
              Entradas
            </Link>
            <Link href="/mi-perfil" className="text-sm hover:text-primary transition">
              Perfil
            </Link>
            {session.rol === 'admin' && (
              <Link href="/admin" className="text-sm text-accent hover:text-primary transition">
                Admin
              </Link>
            )}
            {session.rol === 'dueño' && (
              <Link href="/mis-subastas" className="text-sm text-accent hover:text-primary transition">
                Mis Entradas
              </Link>
            )}
            
            <div className="relative">
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="px-3 py-1 bg-primary text-primary-foreground rounded-lg text-sm hover:opacity-90 transition"
              >
                {session.nombre}
              </button>
              
              {showMenu && (
                <Card className="absolute right-0 mt-2 w-48 p-2">
                  <button
                    onClick={handleLogout}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-muted rounded transition"
                  >
                    Cerrar sesión
                  </button>
                </Card>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
