// "use client"

// Mock database with client-side localStorage support

export interface User {
  id: string
  email: string
  password: string
  username: string
  nombre: string
  billetera: {
    saldo: number
    direccion: string
  }
  rol: "usuario" | "admin" | "dueño"
  createdAt: Date
}

export interface Subasta {
  id: string
  titulo: string
  descripcion: string
  imagen: string
  precioInicial: number
  precioActual: number
  pujaMinima: number
  categoria: string
  ubicacion: string
  fechaInicio: Date
  fechaFin: Date
  estado: "activa" | "terminada" | "cancelada"
  duenoId: string
  ganadorId?: string
  pujas: Puja[]
  allowGuestBids?: boolean // Nueva propiedad para permitir pujas de invitados
}

export interface Puja {
  id: string
  subastaId: string
  usuarioId: string
  monto: number
  timestamp: Date
}

export interface Transaccion {
  id: string
  usuarioId: string
  tipo: "deposito" | "pago" | "reembolso"
  monto: number
  estado: "pendiente" | "exitoso" | "fallido"
  metodo: "mercadopago" | "crypto"
  timestamp: Date
}

export interface GuestBid {
  id: string
  subastaId: string
  username: string
  monto: number
  timestamp: Date
}

const DB_KEYS = {
  USERS: "subasta_users",
  SUBASTAS: "subasta_items",
  PUJAS: "subasta_bids",
  TRANSACCIONES: "subasta_transactions",
  GUEST_BIDS: "subasta_guest_bids",
}


const inMemoryData: { [key: string]: string } = {}

const serverStorage = {
  getItem(key: string) {
    return key in inMemoryData ? inMemoryData[key] : null
  },
  setItem(key: string, value: string) {
    inMemoryData[key] = value
  },
  removeItem(key: string) {
    delete inMemoryData[key]
  },
}

class MockDB {
  private initialized = false

  private getStorage() {
    // En el browser => localStorage real
    if (typeof window !== "undefined" && typeof localStorage !== "undefined") {
      return localStorage
    }
    // En el server => storage en memoria con la misma interfaz
    return serverStorage
  }

  initialize() {
    if (this.initialized) return

    const storage = this.getStorage()

    if (!storage.getItem(DB_KEYS.USERS)) {
      const adminUser: User = {
        id: "admin-1",
        email: "admin@flechatickets.com",
        password: "admin123",
        username: "admin",
        nombre: "Administrador",
        billetera: { saldo: 50000, direccion: "0xAdmin123..." },
        rol: "admin",
        createdAt: new Date(),
      }

      const testUser: User = {
        id: "user-1",
        email: "usuario@flechatickets.com",
        password: "user123",
        username: "usuario_demo",
        nombre: "Usuario Demo",
        billetera: { saldo: 10000, direccion: "0xUser123..." },
        rol: "usuario",
        createdAt: new Date(),
      }

      const duenoUser: User = {
        id: "dueno-1",
        email: "dueno@flechatickets.com",
        password: "dueno123",
        username: "dueno_tickets",
        nombre: "Dueño de Subastas",
        billetera: { saldo: 5000, direccion: "0xDueno123..." },
        rol: "dueño",
        createdAt: new Date(),
      }

      storage.setItem(DB_KEYS.USERS, JSON.stringify([adminUser, testUser, duenoUser]))
    }

    if (!storage.getItem(DB_KEYS.SUBASTAS)) {
      const subastas: Subasta[] = [
        {
          id: "subasta-1",
          titulo: "Entrada VIP - Festival de Música 2025",
          descripcion:
            "Entrada VIP para el Festival de Música 2025 con acceso a zona premium y meet & greet con artistas.",
          imagen: "/vibrant-music-festival.png",
          precioInicial: 500,
          precioActual: 1200,
          pujaMinima: 100,
          categoria: "Entretenimiento",
          ubicacion: "Buenos Aires",
          fechaInicio: new Date(Date.now() - 3600000),
          fechaFin: new Date(Date.now() + 210000), // 3.5 minutes
          estado: "activa",
          duenoId: "dueno-1",
          pujas: [],
          allowGuestBids: true, // Solo subasta-1 permite invitados
        },
        {
          id: "subasta-2",
          titulo: "Boleto Final - Torneo de Fútbol",
          descripcion: "Boleto para la final del torneo de fútbol. Ubicación: Fila 10, Sector A (vista privilegiada).",
          imagen: "/boleto-de-f-tbol.jpg",
          precioInicial: 800,
          precioActual: 2500,
          pujaMinima: 150,
          categoria: "Deportes",
          ubicacion: "CABA",
          fechaInicio: new Date(Date.now() - 7200000),
          fechaFin: new Date(Date.now() + 172800000),
          estado: "activa",
          duenoId: "dueno-1",
          pujas: [],
          allowGuestBids: false,
        },
        {
          id: "subasta-3",
          titulo: "Entrada Concierto - Artista Internacional",
          descripcion: "Entrada general para concierto de artista internacional en estadio.",
          imagen: "/concierto-musical.jpg",
          precioInicial: 300,
          precioActual: 750,
          pujaMinima: 50,
          categoria: "Entretenimiento",
          ubicacion: "La Plata",
          fechaInicio: new Date(Date.now() - 1800000),
          fechaFin: new Date(Date.now() + 259200000),
          estado: "activa",
          duenoId: "dueno-1",
          pujas: [],
          allowGuestBids: false,
        },
      ]
      storage.setItem(DB_KEYS.SUBASTAS, JSON.stringify(subastas))
    }

    if (!storage.getItem(DB_KEYS.GUEST_BIDS)) {
      storage.setItem(DB_KEYS.GUEST_BIDS, JSON.stringify([]))
    }

    if (!storage.getItem(DB_KEYS.TRANSACCIONES)) {
      storage.setItem(DB_KEYS.TRANSACCIONES, JSON.stringify([]))
    }

    this.initialized = true
  }

  // User methods
  getUser(id: string): User | null {
    const storage = this.getStorage()
    const users = JSON.parse(storage.getItem(DB_KEYS.USERS) || "[]")
    return users.find((u: User) => u.id === id) || null
  }

  getUserByEmail(email: string): User | null {
    const storage = this.getStorage()
    const users = JSON.parse(storage.getItem(DB_KEYS.USERS) || "[]")
    return users.find((u: User) => u.email === email) || null
  }

  createUser(email: string, password: string, nombre: string, username: string): User {
    const storage = this.getStorage()
    const users = JSON.parse(storage.getItem(DB_KEYS.USERS) || "[]")
    const newUser: User = {
      id: `user-${Date.now()}`,
      email,
      password,
      username,
      nombre,
      billetera: { saldo: 5000, direccion: `0x${Math.random().toString(16).slice(2)}` },
      rol: "usuario",
      createdAt: new Date(),
    }
    users.push(newUser)
    storage.setItem(DB_KEYS.USERS, JSON.stringify(users))
    return newUser
  }

  updateUserBalance(userId: string, nuevoSaldo: number) {
    const storage = this.getStorage()
    const users = JSON.parse(storage.getItem(DB_KEYS.USERS) || "[]")
    const user = users.find((u: User) => u.id === userId)
    if (user) {
      user.billetera.saldo = nuevoSaldo
      storage.setItem(DB_KEYS.USERS, JSON.stringify(users))
    }
  }

  // Subasta methods
  getAllSubastas(): Subasta[] {
    const storage = this.getStorage()
    return JSON.parse(storage.getItem(DB_KEYS.SUBASTAS) || "[]")
  }

  getSubasta(id: string): Subasta | null {
    const subastas = this.getAllSubastas()
    return subastas.find((s) => s.id === id) || null
  }

  createSubasta(data: Omit<Subasta, "id" | "pujas">): Subasta {
    const storage = this.getStorage()
    const subastas = this.getAllSubastas()
    const newSubasta: Subasta = {
      ...data,
      id: `subasta-${Date.now()}`,
      pujas: [],
    }
    subastas.push(newSubasta)
    storage.setItem(DB_KEYS.SUBASTAS, JSON.stringify(subastas))
    return newSubasta
  }

  updateSubasta(id: string, data: Partial<Subasta>) {
    const storage = this.getStorage()
    const subastas = this.getAllSubastas()
    const index = subastas.findIndex((s) => s.id === id)
    if (index !== -1) {
      subastas[index] = { ...subastas[index], ...data }
      storage.setItem(DB_KEYS.SUBASTAS, JSON.stringify(subastas))
      return true
    }
    return false
  }

  addPuja(subastaId: string, usuarioId: string, monto: number): Puja | null {
    const storage = this.getStorage()
    const subastas = this.getAllSubastas()
    const subasta = subastas.find((s) => s.id === subastaId)

    if (!subasta || subasta.estado !== "activa") return null

    const now = new Date().getTime()
    const end = new Date(subasta.fechaFin).getTime()
    if (now >= end) return null

    if (monto < subasta.precioActual + subasta.pujaMinima) {
      return null
    }

    const newPuja: Puja = {
      id: `puja-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      subastaId,
      usuarioId,
      monto,
      timestamp: new Date(),
    }

    subasta.pujas.push(newPuja)
    subasta.precioActual = monto
    storage.setItem(DB_KEYS.SUBASTAS, JSON.stringify(subastas))
    return newPuja
  }

  getPujasByUser(usuarioId: string): Puja[] {
    const subastas = this.getAllSubastas()
    const pujas: Puja[] = []
    subastas.forEach((s) => {
      pujas.push(...s.pujas.filter((p) => p.usuarioId === usuarioId))
    })
    return pujas
  }

  addGuestBid(subastaId: string, username: string, monto: number): GuestBid | null {
    const storage = this.getStorage()
    const guestBids = JSON.parse(storage.getItem(DB_KEYS.GUEST_BIDS) || "[]")

    const subasta = this.getSubasta(subastaId)
    if (!subasta || !subasta.allowGuestBids || subasta.estado !== "activa") return null

    const now = new Date().getTime()
    const end = new Date(subasta.fechaFin).getTime()
    if (now >= end) return null

    if (monto < subasta.precioActual + subasta.pujaMinima) {
      return null
    }

    const newGuestBid: GuestBid = {
      id: `guest-bid-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
      subastaId,
      username,
      monto,
      timestamp: new Date(),
    }

    guestBids.push(newGuestBid)
    storage.setItem(DB_KEYS.GUEST_BIDS, JSON.stringify(guestBids))

    this.updateSubasta(subastaId, { precioActual: monto })

    return newGuestBid
  }

  getGuestBids(subastaId: string): GuestBid[] {
    const storage = this.getStorage()
    const guestBids = JSON.parse(storage.getItem(DB_KEYS.GUEST_BIDS) || "[]")
    return guestBids.filter((gb: GuestBid) => gb.subastaId === subastaId)
  }

  // Transaccion methods
  addTransaccion(data: Omit<Transaccion, "id">): Transaccion {
    const storage = this.getStorage()
    const transacciones = JSON.parse(storage.getItem(DB_KEYS.TRANSACCIONES) || "[]")
    const newTransaccion: Transaccion = {
      ...data,
      id: `trans-${Date.now()}`,
    }
    transacciones.push(newTransaccion)
    storage.setItem(DB_KEYS.TRANSACCIONES, JSON.stringify(transacciones))
    return newTransaccion
  }

  getTransacciones(usuarioId: string): Transaccion[] {
    const storage = this.getStorage()
    const transacciones = JSON.parse(storage.getItem(DB_KEYS.TRANSACCIONES) || "[]")
    return transacciones.filter((t: Transaccion) => t.usuarioId === usuarioId)
  }

  determineWinner(subastaId: string): string | null {
    const subasta = this.getSubasta(subastaId)
    if (!subasta) return null

    const allBids = [...subasta.pujas, ...this.getGuestBids(subastaId)]
    if (allBids.length === 0) return null

    const winningBid = allBids.reduce((max, bid) => (bid.monto > max.monto ? bid : max))
    const isGuestBid = "username" in winningBid

    return isGuestBid ? winningBid.username : winningBid.usuarioId
  }
}

export const db = new MockDB()

// Inicializamos siempre; adentro de initialize() usamos getStorage()
// que ya distingue entre browser (localStorage) y server (serverStorage).
db.initialize()
