import { db } from './mock-db'

const AUTH_KEY = 'subasta_session'

export interface Session {
  userId: string
  email: string
  username: string
  nombre: string
  rol: 'usuario' | 'admin' | 'dueño'
}

export function login(email: string, password: string): Session | null {
  const user = db.getUserByEmail(email)
  if (user && user.password === password) {
    const session: Session = {
      userId: user.id,
      email: user.email,
      username: user.username,
      nombre: user.nombre,
      rol: user.rol,
    }
    if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
      localStorage.setItem(AUTH_KEY, JSON.stringify(session))
    }
    return session
  }
  return null
}

export function register(email: string, password: string, nombre: string, username: string): Session | null {
  const existing = db.getUserByEmail(email)
  if (existing) return null
  
  const user = db.createUser(email, password, nombre, username)
  const session: Session = {
    userId: user.id,
    email: user.email,
    username: user.username,
    nombre: user.nombre,
    rol: user.rol,
  }
  if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
    localStorage.setItem(AUTH_KEY, JSON.stringify(session))
  }
  return session
}

export function logout() {
  if (typeof window !== 'undefined' && typeof localStorage !== 'undefined') {
    localStorage.removeItem(AUTH_KEY)
  }
}

export function getSession(): Session | null {
  if (typeof window === 'undefined') return null
  const session = localStorage.getItem(AUTH_KEY)
  return session ? JSON.parse(session) : null
}
